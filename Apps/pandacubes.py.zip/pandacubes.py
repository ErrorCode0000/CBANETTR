# Gerekli Panda3D modüllerini ve diğer kütüphaneleri içe aktar
from direct.showbase.ShowBase import ShowBase
from direct.showbase.DirectObject import DirectObject
from panda3d.core import AmbientLight, DirectionalLight, VBase4, CollisionRay, CollisionNode, CollisionHandlerQueue, BitMask32, TextNode, CollisionSphere, CollisionTraverser, ClockObject, LVector3, Material, TransformState
from direct.gui.OnscreenText import OnscreenText
from direct.task import Task
import random
import sys

# ShowBase'i burada global olarak başlatıyoruz.
base = ShowBase()

# base.cTrav'ı manuel olarak başlatıyoruz (Panda3D başlatma hatasını gidermek için)
if not isinstance(base.cTrav, CollisionTraverser):
    print("Uyarı: base.cTrav beklenildiği gibi bir CollisionTraverser değil. Manuel olarak başlatılıyor.")
    base.cTrav = CollisionTraverser('my_collision_traverser')

# globalClock'ı manuel olarak base'e atıyoruz (Panda3D başlatma hatasını gidermek için)
if not hasattr(base, 'globalClock') or not isinstance(base.globalClock, ClockObject):
    print("Uyarı: base.globalClock bulunamadı veya beklenildiği gibi bir ClockObject değil. Manuel olarak atanıyor.")
    base.globalClock = ClockObject.getGlobalClock()

class CubeBlastGame(DirectObject):
    def __init__(self):
        # 1. Sahneyi ve Kamerayı Ayarla
        base.disableMouse()
        base.camera.setPos(0, -20, 5) # Kamerayı başlangıç pozisyonuna ayarla
        base.camera.lookAt(0, 0, 0) # Kamerayı merkeze baktır

        # 2. Işıklandırma Ekle
        self.isiklandirma_ekle()

        # 3. Oyun Değişkenleri
        self.score = 0
        self.money = 0 # Para sadece birikecek, harcanmayacak
        self.max_cubes = 15
        self.current_cubes = 0
        self.cubes = []
        self.game_over_status = False
        self.spawn_center = base.camera.getPos() + base.camera.getQuat().getForward() * 20

        # Renk Sistemleri (Sadece başlangıç renkleri geçerli olacak, diğerleri kullanılmayacak)
        self.initial_unlocked_colors_info = {
            "Siyah": {"color": VBase4(0, 0, 0, 1), "price": 0, "unlocked": True, "shininess": 0},
            "Varsayılan Gri": {"color": VBase4(0.8, 0.8, 0.8, 1), "price": 0, "unlocked": True, "shininess": 0}
        }
        self.unlocked_colors = list(self.initial_unlocked_colors_info.values())

        # Bu dictionary artık kullanılmayacak, dükkan sistemi kalktı
        # self.colors_for_sale = {...}
        # self.current_shop_item_index = 0
        # self.shop_item_names = list(self.colors_for_sale.keys())

        # 4. GUI (Ekran Üstü Metin)
        self.score_text = OnscreenText(text=f"Puan: {self.score}", pos=(0.85, -0.95), scale=0.07, fg=(1, 1, 1, 1), align=TextNode.ARight)
        self.money_text = OnscreenText(text=f"Para: ${self.money}", pos=(-0.85, -0.95), scale=0.07, fg=(1, 1, 0, 1), align=TextNode.ALeft)
        self.info_text = OnscreenText(text="Tüm Küpleri Patlat!", pos=(0, 0.9), scale=0.1, fg=(1, 1, 1, 1), align=TextNode.ACenter)

        # Dükkan metnini artık oluşturmuyoruz
        # self.shop_text = OnscreenText(...)
        # self.update_shop_display() # Bu çağrıya gerek kalmadı

        # 5. Küpleri Oluştur ve Yerleştir
        self.create_initial_cubes(self.max_cubes)

        # 6. Kamera Kontrollerini Ayarla
        self.setup_kamera_hareketi()

        # 7. Fare Etkileşimi ve Çarpışma Tespiti Kurulumu
        self.setup_fare_etkilesimi()

        # Dükkan kontrollerini artık kurmuyoruz
        # self.setup_shop_controls()

        # 8. Oyun Güncelleme Görevini Ekle
        base.taskMgr.add(self.update_game, "update_game_gorevi")

    def isiklandirma_ekle(self):
        ambientLight = AmbientLight("ambientLight")
        ambientLight.setColor(VBase4(0.3, 0.3, 0.3, 1))
        ambientLightNP = base.render.attachNewNode(ambientLight)
        base.render.setLight(ambientLightNP)

        directionalLight = DirectionalLight("directionalLight")
        directionalLight.setColor(VBase4(0.7, 0.7, 0.7, 1))
        directionalLightNP = base.render.attachNewNode(directionalLight)
        directionalLightNP.setHpr(45, -45, 0)
        base.render.setLight(directionalLightNP)

    def create_initial_cubes(self, count):
        for i in range(count):
            self.spawn_cube()

    def spawn_cube(self):
        if self.current_cubes >= self.max_cubes:
            return

        x = self.spawn_center.getX() + random.uniform(-10, 10)
        y = self.spawn_center.getY() + random.uniform(-10, 10)
        z = self.spawn_center.getZ() + random.uniform(-5, 8)

        cube = base.loader.loadModel("models/misc/rgbCube")
        cube.reparentTo(base.render)
        cube.setPos(x, y, z)
        cube.setScale(1.5)

        # Sadece initial_unlocked_colors_info'dan renk seçecek
        random_color_info = random.choice(self.unlocked_colors)
        target_color = random_color_info["color"]
        target_shininess = random_color_info.get("shininess", 0)

        mat = Material()
        mat.setDiffuse(target_color)
        mat.setSpecular(VBase4(1, 1, 1, 1))
        mat.setShininess(target_shininess)
        cube.setMaterial(mat, 1)

        cube_id = f"cube-{random.randint(0, 100000)}-{self.current_cubes}"
        cube.setName(cube_id)

        collider_node = CollisionNode('cube_collider')
        collider_node.addSolid(CollisionSphere(0, 0, 0, 1.0))
        collider_node.setFromCollideMask(BitMask32.allOff())
        collider_node.setIntoCollideMask(BitMask32.bit(0))
        collider_np = cube.attachNewNode(collider_node)
        collider_np.setTag('cube_name', cube_id)

        self.cubes.append(cube)
        self.current_cubes += 1

    def setup_kamera_hareketi(self):
        self.keys = {"w": False, "s": False, "a": False, "d": False,
                     "arrow_up": False, "arrow_down": False, "arrow_left": False, "arrow_right": False}

        self.accept("w", self.set_key, ["w", True])
        self.accept("w-up", self.set_key, ["w", False])
        self.accept("s", self.set_key, ["s", True])
        self.accept("s-up", self.set_key, ["s", False])
        self.accept("a", self.set_key, ["a", True])
        self.accept("a-up", self.set_key, ["a", False])
        self.accept("d", self.set_key, ["d", True])
        self.accept("d-up", self.set_key, ["d", False])

        self.accept("arrow_left", self.set_key, ["arrow_left", True])
        self.accept("arrow_left-up", self.set_key, ["arrow_left", False])
        self.accept("arrow_right", self.set_key, ["arrow_right", True])
        self.accept("arrow_right-up", self.set_key, ["arrow_right", False])

        self.accept("arrow_up", self.set_key, ["arrow_up", True])
        self.accept("arrow_up-up", self.set_key, ["arrow_up", False])
        self.accept("arrow_down", self.set_key, ["arrow_down", True])
        self.accept("arrow_down-up", self.set_key, ["arrow_down", False])

        self.kamera_hizi = 15.0
        self.kamera_donme_hizi = 100.0
        self.kamera_egilme_hizi = 80.0

    def set_key(self, key, value):
        self.keys[key] = value

    def update_kamera(self, dt):
        if self.keys["w"]:
            base.camera.setY(base.camera, self.kamera_hizi * dt)
        if self.keys["s"]:
            base.camera.setY(base.camera, -self.kamera_hizi * dt)

        if self.keys["a"]:
            base.camera.setX(base.camera, -self.kamera_hizi * dt)
        if self.keys["d"]:
            base.camera.setX(base.camera, self.kamera_hizi * dt)

        if self.keys["arrow_left"]:
            base.camera.setH(base.camera, self.kamera_donme_hizi * dt)
        if self.keys["arrow_right"]:
            base.camera.setH(base.camera, -self.kamera_donme_hizi * dt)

        if self.keys["arrow_up"]:
            base.camera.setP(base.camera, -self.kamera_egilme_hizi * dt)
        if self.keys["arrow_down"]:
            base.camera.setP(base.camera, self.kamera_egilme_hizi * dt)

    def setup_fare_etkilesimi(self):
        self.accept("mouse1", self.on_sol_tik)

        self.picker_ray = CollisionRay()
        self.picker_node = CollisionNode('mouseRay')
        self.picker_node.addSolid(self.picker_ray)
        self.picker_node.setFromCollideMask(BitMask32.bit(0))
        self.picker_node.setIntoCollideMask(BitMask32.allOff())

        self.picker_np = base.camera.attachNewNode(self.picker_node)

        self.collision_handler = CollisionHandlerQueue()
        base.cTrav.addCollider(self.picker_np, self.collision_handler)

    def on_sol_tik(self):
        if self.game_over_status:
            return

        if base.mouseWatcherNode.hasMouse():
            mpos = base.mouseWatcherNode.getMouse()

            self.picker_ray.setFromLens(base.camNode, mpos.getX(), mpos.getY())

            base.cTrav.traverse(base.render)

            if self.collision_handler.getNumEntries() > 0:
                self.collision_handler.sortEntries()
                picked_entry = self.collision_handler.getEntry(0)

                hit_collider_np = picked_entry.getIntoNodePath()
                cube_name_tag = hit_collider_np.getTag('cube_name')

                if cube_name_tag:
                    found_cube = None
                    for cube_node in self.cubes:
                        if cube_node.getName() == cube_name_tag:
                            found_cube = cube_node
                            break

                    if found_cube:
                        self.patlat_kup(found_cube)
                    else:
                        print(f"Uyarı: '{cube_name_tag}' adına sahip küp listede bulunamadı (on_sol_tik).")
                else:
                    print("Uyarı: Tıklanan nesnenin 'cube_name' etiketi yok.")
        else:
            print("Fare pencerenin dışında.")

    def patlat_kup(self, cube_node_path):
        if cube_node_path in self.cubes:
            cube_node_path.removeNode()
            self.cubes.remove(cube_node_path)
            self.score += 10
            self.score_text.setText(f"Puan: {self.score}")
            self.money += 5 # Para birikmeye devam edecek
            self.money_text.setText(f"Para: ${self.money}")
            self.current_cubes -= 1

            # Artık check_auto_buy() çağrılmıyor
            # self.check_auto_buy()

            if not self.cubes:
                self.game_over("Kazandınız!")
            else:
                self.spawn_cube()
        else:
            print(f"Uyarı: '{cube_node_path.getName()}' adlı küp zaten listede değildi (patlat_kup).")

    # --- Dükkan Metodları (Kaldırıldı veya devre dışı bırakıldı) ---
    def setup_shop_controls(self):
        # Dükkan kontrolleri artık dinlenmiyor
        self.ignore("n")
        self.ignore("b")

    # Bu metodlar artık çağrılmayacağı için silinebilir veya yorum satırı yapılabilir
    # def update_shop_display(self):
    #     pass
    # def show_next_shop_item(self):
    #     pass
    # def show_prev_shop_item(self):
    #     pass
    # def buy_shop_item(self, item_name_to_buy=None):
    #     pass
    # def check_auto_buy(self):
    #     pass

    def clear_info_text(self, task):
        self.info_text.setText("Tüm Küpleri Patlat!")
        self.info_text.setFg(VBase4(1, 1, 1, 1))
        return Task.done

    # --- Oyun Yönetimi Metodları ---
    def reset_game(self):
        for cube in list(self.cubes):
            cube.removeNode()
        self.cubes.clear()

        self.score = 0
        # Para sıfırlanmayacak, birikmeye devam edecek. Eğer sıfırlanmasını istersen
        # self.money = 0
        self.money_text.setText(f"Para: ${self.money}") # UI'da güncellensin

        self.current_cubes = 0
        self.game_over_status = False

        self.score_text.setText(f"Puan: {self.score}")
        self.info_text.setText("Tüm Küpleri Patlat!")
        self.info_text.setFg(VBase4(1, 1, 1, 1))

        # unlocked_colors listesini sadece başlangıçtaki renklere sıfırla
        self.unlocked_colors = list(self.initial_unlocked_colors_info.values())

        # Bu kısım artık dükkan yoksa gerekli değil
        # for item_name in self.colors_for_sale:
        #     if item_name in self.initial_unlocked_colors_info:
        #         self.colors_for_sale[item_name]["unlocked"] = True
        #     else:
        #         self.colors_for_sale[item_name]["unlocked"] = False
        # self.update_shop_display() # Dükkan ekranını artık güncellemeye gerek yok

        self.spawn_center = base.camera.getPos() + base.camera.getQuat().getForward() * 20

        self.create_initial_cubes(self.max_cubes)

        # Kontrolleri tekrar etkinleştir
        self.accept("mouse1", self.on_sol_tik)
        # Dükkan tuşları artık etkinleştirilmiyor
        # self.accept("n", self.show_next_shop_item)
        # self.accept("b", self.show_prev_shop_item)

    def update_game(self, task):
        if self.game_over_status:
            return Task.cont

        dt = base.globalClock.getDt()
        self.update_kamera(dt)

        return Task.cont

    def reset_game_after_delay(self, task):
        self.reset_game()
        self.info_text.setText("Oyuna Devam!")
        self.info_text.setFg(VBase4(1, 1, 1, 1))
        base.taskMgr.doMethodLater(2, self.clear_info_text, "clear_info")
        return Task.done

    def game_over(self, message):
        self.game_over_status = True
        self.info_text.setText(message + "\nYeni Tur Başlıyor...")
        self.info_text.setPos(0, 0)
        self.info_text.setScale(0.15)
        # Oyun bitişinde sadece fare tıklamasını devre dışı bırak
        self.ignore("mouse1")
        # Dükkan tuşlarını artık ignore etmeye gerek yok çünkü zaten dinlenmiyorlar
        # self.ignore("n")
        # self.ignore("b")
        print(f"Oyun Bitti! {message}")

        base.taskMgr.doMethodLater(2, self.reset_game_after_delay, "reset_game_after_delay_task")


# Oyunu başlat
game = CubeBlastGame()
base.run()
