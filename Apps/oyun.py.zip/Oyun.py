import tkinter as tk
import random
import time
import numpy as np
import pyaudio

# --- Sabit Ayarlar ---
BUTTON_COLORS = {
    "red": "#e74c3c",    # Kırmızı
    "green": "#2ecc71",  # Yeşil
    "blue": "#3498db",   # Mavi
    "yellow": "#f1c40f", # Sarı
    "error": "#c0392b"   # Hata için renk
}
# Her renk için atanmış frekanslar (Hz)
BUTTON_FREQUENCIES = {
    "red": 440,
    "green": 523,
    "blue": 659,
    "yellow": 783,
    "error": 220
}
FLASH_DURATION = 200 # Milisaniye cinsinden tuşun yanıp sönme süresi
NOTE_DURATION = 150  # Milisaniye cinsinden sesin çalma süresi
PLAY_SPEED = 800     # Milisaniye cinsinden notalar arası bekleme süresi (sekans oynatma hızı)
SAMPLE_RATE = 44100  # Örnekleme oranı (Hz)
VOLUME = 0.5         # Ses seviyesi (0.0 - 1.0 arası)

# --- Oyun Değişkenleri ---
game_sequence = []
player_sequence = []
is_player_turn = False
score = 0
level = 1
buttons = {}

# --- PyAudio Ayarları ---
p = pyaudio.PyAudio()
stream = p.open(format=pyaudio.paFloat32,
                channels=1,
                rate=SAMPLE_RATE,
                output=True)

# --- Ses Fonksiyonları ---
def generate_sine_wave(frequency, duration):
    t = np.linspace(0, duration / 1000, int(SAMPLE_RATE * duration / 1000), False)
    return np.sin(2 * np.pi * frequency * t)

def play_frequency_sound(frequency, duration=NOTE_DURATION):
    audio = (generate_sine_wave(frequency, duration) * VOLUME).astype(np.float32)
    stream.write(audio.tobytes())

# --- Görsel Geri Bildirim Fonksiyonları ---
def flash_button(color, is_highlight=True):
    original_color = BUTTON_COLORS[color]
    highlight_color = "#ecf0f1" if original_color != "#f1c40f" else "#f39c12"

    if is_highlight:
        buttons[color].config(bg=highlight_color)
        play_frequency_sound(BUTTON_FREQUENCIES[color])
    else:
        buttons[color].config(bg=original_color)
    
    root.update_idletasks()

def show_message(msg, color="black"):
    message_label.config(text=msg, fg=color)

# --- Oyun Mantığı Fonksiyonları ---
def start_game():
    """Oyunu başlatır veya mevcut oyunu sıfırlayıp yeniden başlatır."""
    global game_sequence, player_sequence, is_player_turn, score, level
    game_sequence = []
    player_sequence = [] # Oyuna başlarken de sıfırla
    is_player_turn = False
    score = 0
    level = 1
    update_score_label()
    update_level_label()
    show_message("Oyun Başlıyor...", "blue")
    start_button.config(state=tk.DISABLED)
    
    root.after(1000, add_to_sequence)

def add_to_sequence():
    """
    Oyun sekansına yeni bir renk ekler ve ardından tüm sekansı oynatır.
    """
    global is_player_turn, level
    is_player_turn = False
    show_message("Sırayı İzle...", "black")
    
    next_color = random.choice(list(BUTTON_COLORS.keys())[:-1]) 
    game_sequence.append(next_color)
    
    root.after(500, play_sequence)

def play_sequence(index=0):
    """
    Oyun sekansını sırayla oynatır (tuşları yakıp söndürür ve seslerini çalar).
    """
    global is_player_turn
    if index < len(game_sequence):
        color = game_sequence[index]
        flash_button(color, True)
        root.after(FLASH_DURATION, flash_button, color, False)
        root.after(FLASH_DURATION + (PLAY_SPEED - FLASH_DURATION), play_sequence, index + 1)
    else:
        # Sekans oynatma bitti, sıra oyuncuya geçmeden önce player_sequence'ı sıfırla
        player_sequence.clear() # player_sequence'ı boşalt
        is_player_turn = True
        show_message("Şimdi Senin Sıran! Sekansı tekrar et.", "green")

def on_button_click(color):
    """
    Oyuncu bir tuşa tıkladığında tetiklenir.
    Oyuncunun girdisini kaydeder ve sekans tamamlandığında kontrol eder.
    """
    global player_sequence, is_player_turn, score, level

    if not is_player_turn:
        return

    flash_button(color, True)
    root.after(FLASH_DURATION, flash_button, color, False)

    player_sequence.append(color)

    # Oyuncu, oyunun gösterdiği sekans kadar tuşa basmışsa kontrol zamanı
    if len(player_sequence) == len(game_sequence):
        if player_sequence == game_sequence:
            score += level
            level += 1
            update_score_label()
            update_level_label()
            show_message("Doğru! Bir sonraki seviye...", "purple")
            is_player_turn = False
            root.after(1500, add_to_sequence)
        else:
            game_over()
    elif len(player_sequence) > len(game_sequence):
        # Bu durum, oyuncunun beklenenden fazla tuşa basması durumunda oyunu bitirir.
        # Bu aynı zamanda, oyuncu sekansın ortasında yanlış bir tuşa basarsa da oyunu bitirir,
        # çünkü player_sequence uzunluğu oyunun olması gereken uzunluğunu geçer.
        game_over()


def game_over():
    """Oyun bittiğinde çağrılır. Hata geri bildirimi yapar ve oyunu sıfırlar."""
    global is_player_turn
    is_player_turn = False
    
    for i in range(3):
        for c in ["red", "green", "blue", "yellow"]:
            buttons[c].config(bg=BUTTON_COLORS["error"])
        play_frequency_sound(BUTTON_FREQUENCIES["error"], 300)
        root.update_idletasks()
        time.sleep(0.15)
        for c in ["red", "green", "blue", "yellow"]:
            buttons[c].config(bg=BUTTON_COLORS[c])
        root.update_idletasks()
        time.sleep(0.15)

    show_message(f"Oyun Bitti! Puanın: {score}", "red")
    
    start_button.config(text="Yeniden Başla", command=start_game, state=tk.NORMAL)

def update_score_label():
    """Puan etiketinin metnini günceller."""
    score_label.config(text=f"Puan: {score}")

def update_level_label():
    """Seviye etiketinin metnini günceller."""
    level_label.config(text=f"Seviye: {level}")

def change_difficulty(speed_change, flash_change):
    """
    Oyunun hızını (PLAY_SPEED) ve tuşların yanıp sönme süresini (FLASH_DURATION) ayarlar.
    """
    global PLAY_SPEED, FLASH_DURATION
    PLAY_SPEED = max(200, PLAY_SPEED + speed_change)
    FLASH_DURATION = max(50, FLASH_DURATION + flash_change)
    show_message(f"Zorluk Ayarlandı! Hız: {PLAY_SPEED}ms, Yanıp Sönme: {FLASH_DURATION}ms", "orange")

# --- Tkinter Arayüzü Oluşturma ---
root = tk.Tk()
root.title("Oyun")
root.geometry("400x600")
root.resizable(False, False)
root.config(bg="#f0f0f0")

# Mesaj, Puan ve Seviye Etiketleri
message_label = tk.Label(root, text="Oyuna Başlamak İçin 'Başla'ya Tıkla", font=('Arial', 14, 'bold'), fg="black", bg="#f0f0f0")
message_label.pack(pady=10)

score_label = tk.Label(root, text="Puan: 0", font=('Arial', 12), fg="#333", bg="#f0f0f0")
score_label.pack(pady=5)

level_label = tk.Label(root, text="Seviye: 1", font=('Arial', 12), fg="#333", bg="#f0f0f0")
level_label.pack(pady=5)

# Oyun Tuşları Çerçevesi
button_frame = tk.Frame(root, bg="#333333", bd=5, relief=tk.RIDGE)
button_frame.pack(pady=20)

# Butonları oluştur ve `buttons` sözlüğüne kaydet
red_button = tk.Button(button_frame, bg=BUTTON_COLORS["red"], activebackground="#e74c3c", command=lambda: on_button_click("red"), width=10, height=5, relief=tk.RAISED, bd=3)
red_button.grid(row=0, column=0, padx=5, pady=5)
buttons["red"] = red_button

green_button = tk.Button(button_frame, bg=BUTTON_COLORS["green"], activebackground="#2ecc71", command=lambda: on_button_click("green"), width=10, height=5, relief=tk.RAISED, bd=3)
green_button.grid(row=0, column=1, padx=5, pady=5)
buttons["green"] = green_button

blue_button = tk.Button(button_frame, bg=BUTTON_COLORS["blue"], activebackground="#3498db", command=lambda: on_button_click("blue"), width=10, height=5, relief=tk.RAISED, bd=3)
blue_button.grid(row=1, column=0, padx=5, pady=5)
buttons["blue"] = blue_button

yellow_button = tk.Button(button_frame, bg=BUTTON_COLORS["yellow"], activebackground="#f1c40f", command=lambda: on_button_click("yellow"), width=10, height=5, relief=tk.RAISED, bd=3)
yellow_button.grid(row=1, column=1, padx=5, pady=5)
buttons["yellow"] = yellow_button

# Zorluk Ayar Butonları
difficulty_frame = tk.Frame(root, bg="#f0f0f0")
difficulty_frame.pack(pady=10)

slower_button = tk.Button(difficulty_frame, text="Daha Yavaş", command=lambda: change_difficulty(100, 20), bg="#3498db", fg="white", bd=3)
slower_button.pack(side=tk.LEFT, padx=5)

faster_button = tk.Button(difficulty_frame, text="Daha Hızlı", command=lambda: change_difficulty(-100, -20), bg="#e74c3c", fg="white", bd=3)
faster_button.pack(side=tk.RIGHT, padx=5)

# Başla Butonu
start_button = tk.Button(root, text="OYUNU BAŞLA", font=('Arial', 16, 'bold'), command=start_game, bg="#28a745", fg="white", activebackground="#218838", bd=5, relief=tk.RAISED)
start_button.pack(pady=20)

# Tkinter ana döngüsünü başlat
root.mainloop()

# Uygulama kapandığında PyAudio kaynaklarını temizle
stream.stop_stream()
stream.close()
p.terminate()