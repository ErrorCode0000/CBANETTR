import tkinter as tk
from PIL import ImageGrab, Image, ImageTk

def renk_filtresi(image):
    """Basit bir kırmızı ton filtresi uygular."""
    width, height = image.size
    pixels = image.load()
    for x in range(width):
        for y in range(height):
            r, g, b = pixels[x, y]
            # Kırmızı tonu artır, diğerlerini azalt
            new_r = min(255, int(r * 1.5))
            new_g = max(0, int(g * 0.7))
            new_b = max(0, int(b * 0.7))
            pixels[x, y] = (new_r, new_g, new_b)
    return image

def ekrani_guncelle():
    global panel
    try:
        # Tüm ekranın görüntüsünü al
        bbox = (0, 0, root.winfo_screenwidth(), root.winfo_screenheight())
        img = ImageGrab.grab(bbox=bbox)

        # Renk filtresini uygula
        filtered_img = renk_filtresi(img)

        # Tkinter uyumlu hale getir
        imgtk = ImageTk.PhotoImage(filtered_img)
        panel.imgtk = imgtk
        panel.config(image=imgtk)

        # Belirli aralıklarla tekrar çağır
        root.after(30, ekrani_guncelle)  # Yaklaşık 30 milisaniyede bir (yüksek CPU kullanımı olabilir)

    except Exception as e:
        print(f"Hata oluştu: {e}")
        root.after(500, ekrani_guncelle) # Hata durumunda daha yavaş tekrar dene

root = tk.Tk()
root.attributes("-fullscreen", True)
root.attributes("-topmost", True)
root.attributes("-transparentcolor", "white") # Tamamen şeffaf yapmaya çalışır (sistem desteklemeyebilir)
root.geometry(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}+0+0")

panel = tk.Label(root, image=None)
panel.pack(fill="both", expand=True)

# Beyaz bir arka plan oluştur (şeffaflık için)
empty_image = ImageTk.PhotoImage(Image.new("RGB", (1, 1), "white"))
panel.config(image=empty_image)

ekrani_guncelle()

root.mainloop()