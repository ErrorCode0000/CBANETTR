import subprocess
import sys
import os
import random
import hashlib
import time

# --- Kütüphane Kontrol ve Kurulum Fonksiyonu ---
def install_missing_libraries():
    """Gerekli Python kütüphanelerini kontrol eder ve eksikse kurar."""
    required_libraries = ['Pillow', 'qrcode']
    missing_libraries = []

    for lib in required_libraries:
        try:
            # kütüphaneyi içe aktarmayı dene
            # Pillow'un içe aktarma adı 'PIL' olabilir
            if lib == 'Pillow':
                __import__('PIL')
            else:
                __import__(lib.lower())
        except ImportError:
            missing_libraries.append(lib)

    if missing_libraries:
        print("Eksik kütüphaneler tespit edildi. Kurulum deneniyor...")
        print(f"Eksik: {', '.join(missing_libraries)}")
        try:
            # pip komutunu kullanarak kütüphaneleri kur
            subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing_libraries)
            print("Kütüphaneler başarıyla kuruldu.")
        except subprocess.CalledProcessError as e:
            print(f"Kütüphane kurulumu başarısız oldu: {e}")
            print("Lütfen yukarıdaki hatayı inceleyin ve kütüphaneleri manuel olarak kurmayı deneyin:")
            print(f"pip install {' '.join(missing_libraries)}")
            sys.exit(1) # Kurulum başarısız olursa uygulamayı kapat
    else:
        print("Gerekli tüm kütüphaneler yüklü.")

# --- Kütüphane Kontrolünü Uygulama Başında Çağır ---
install_missing_libraries()

# Kütüphaneler kontrol edildikten ve kurulduktan sonra içe aktarılır
import tkinter as tk
from tkinter import messagebox
# random, hashlib, time zaten en başta içe aktarıldı
import qrcode
from PIL import Image, ImageTk

# --- Sabitler ve Ayarlar ---
QR_CODE_SIZE = 200 # QR kod boyutu
QR_CODE_VERSION = 1
LOCK_TIMEOUT_SECONDS = 300  # 5 dakika sonra uyku moduna geç/kapat
ADMIN_PASSWORD_HASH = hashlib.sha256("CBAdmin".encode()).hexdigest()
# DIGITAL_PANEL_FILE sabiti ve ilgili fonksiyonlar kaldırıldı.

# --- Global Değişkenler ---
current_qr_code_password = ""
lock_window = None
timeout_id = None
# digital_panel_label global değişkeni kaldırıldı.

# --- Yardımcı Fonksiyonlar ---

def generate_random_qr_password():
    """6 haneli rastgele bir sayısal parola üretir."""
    return ''.join(random.choices('0123456789', k=6))

def generate_qr_code(data):
    """Verilen veriyle bir QR kodu oluşturur ve Image nesnesi döndürür."""
    qr = qrcode.QRCode(
        version=QR_CODE_VERSION,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    img = img.resize((QR_CODE_SIZE, QR_CODE_SIZE), Image.Resampling.LANCZOS)
    return img

def hash_password(password):
    """Parolayı SHA256 ile hash'ler."""
    return hashlib.sha256(password.encode()).hexdigest()

def apply_os_specific_lock():
    """İşletim sistemine özgü kilit önlemlerini uygular (örneğin explorer.exe kill)."""
    if sys.platform.startswith('win'): # Windows
        print("Windows: explorer.exe sonlandırılıyor...")
        try:
            subprocess.run(['taskkill', '/f', '/im', 'explorer.exe'], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
        except subprocess.CalledProcessError as e:
            print(f"explorer.exe sonlandırılamadı: {e}")
        except FileNotFoundError:
            print("taskkill bulunamadı.")
    elif sys.platform.startswith('linux'): # Linux (Ubuntu/Pardus)
        print("Linux: Masaüstü kabuğunu kill etme uygun değil. Tkinter tam ekran kilit sağlıyor.")
    elif sys.platform == 'darwin': # macOS
        print("macOS: Masaüstü kabuğunu kill etme uygun değil. Tkinter tam ekran kilit sağlıyor.")
    else:
        print(f"Desteklenmeyen işletim sistemi: {sys.platform}. Özel kilit önlemleri yok.")

def restore_os_specific_desktop():
    """İşletim sistemine özgü masaüstü işlemlerini geri yükler (örneğin explorer.exe başlatma)."""
    if sys.platform.startswith('win'): # Windows
        print("Windows: explorer.exe başlatılıyor...")
        try:
            subprocess.Popen(['explorer.exe'], creationflags=subprocess.CREATE_NO_WINDOW)
        except FileNotFoundError:
            print("explorer.exe bulunamadı.")
    elif sys.platform.startswith('linux'): # Linux
        print("Linux: Masaüstü kabuğunu otomatik olarak restore etme işlemi yok.")
    elif sys.platform == 'darwin': # macOS
        print("macOS: Masaüstü otomatik olarak restore etme işlemi yok.")
    else:
        print(f"Desteklenmeyen işletim sistemi: {sys.platform}. Masaüstü restore işlemleri yok.")


def disable_system_monitoring():
    """Sistem izleme araçlarını devre dışı bırakmayı dener (Placeholder)."""
    print(f"{sys.platform}: Sistem izleme araçlarını devre dışı bırakma özelliği tam örneklenmemiştir.")
    pass

def enable_system_monitoring():
    """Sistem izleme araçlarını etkinleştirmeyi dener (Placeholder)."""
    print(f"{sys.platform}: Sistem izleme araçlarını etkinleştirme özelliği tam örneklenmemiştir.")
    pass

def send_to_sleep_or_shutdown():
    """Belirlenen süre sonunda sistemi uyku moduna alır veya kapatır (Platforma özel)."""
    if sys.platform.startswith('win'): # Windows
        print("Windows: Sistem uyku moduna alınıyor...")
        try:
            subprocess.run(['rundll32.exe', 'powrprof.dll,SetSuspendState', '0,1,0'], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
        except Exception as e:
            print(f"Windows uyku modu başarısız: {e}. Kapatma deneniyor...")
            try:
                subprocess.run(['shutdown', '/s', '/t', '0'], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
            except Exception as e:
                print(f"Windows kapatma başarısız: {e}.")
    elif sys.platform.startswith('linux'): # Linux (Ubuntu/Pardus)
        print("Linux: Sistem uyku moduna alınıyor...")
        try:
            subprocess.run(['systemctl', 'suspend'], check=True)
        except subprocess.CalledProcessError as e:
            print(f"Linux uyku modu başarısız: {e}. Yetkilendirme (sudo) gerekebilir. Kapatma deneniyor...")
            try:
                subprocess.run(['systemctl', 'poweroff'], check=True) # Bu da sudo isteyebilir
            except subprocess.CalledProcessError as e:
                print(f"Linux kapatma başarısız: {e}. Yetkilendirme (sudo) gerekebilir.")
    elif sys.platform == 'darwin': # macOS
        print("macOS: Sistem uyku moduna alınıyor...")
        try:
            subprocess.run(['pmset', 'sleepnow'], check=True)
        except Exception as e:
            print(f"macOS uyku modu başarısız: {e}. Kapatma deneniyor...")
            try:
                subprocess.run(['osascript', '-e', 'tell app "System Events" to shut down'], check=True)
            except Exception as e:
                print(f"macOS kapatma başarısız: {e}.")
    else:
        print(f"Desteklenmeyen işletim sistemi: {sys.platform}. Uyku/kapatma komutu yok.")

    if lock_window:
        lock_window.destroy()
    sys.exit()

# Dijital pano okuma ve güncelleme fonksiyonları kaldırıldı.

# --- Kilit Ekranı Fonksiyonları ---
def check_password(password_entry_widget):
    global lock_window
    entered_password = password_entry_widget.get()

    if entered_password == current_qr_code_password or hash_password(entered_password) == ADMIN_PASSWORD_HASH:
        messagebox.showinfo("CBA-Kilit", "Kilit Açıldı!")
        unlock_system()
    else:
        messagebox.showerror("CBA-Kilit", "Hatalı parola!")
        password_entry_widget.delete(0, tk.END)

def unlock_system():
    global lock_window, timeout_id
    if lock_window:
        if timeout_id:
            lock_window.after_cancel(timeout_id)
        lock_window.destroy()
        lock_window = None
    restore_os_specific_desktop()
    enable_system_monitoring()
    print("Sistem kilidi açıldı ve servisler başlatıldı.")
    sys.exit()

def on_closing():
    messagebox.showerror("CBA-Kilit", "Bu pencere kapatılamaz! Lütfen kilidi açın.")
    if lock_window:
        lock_window.protocol("WM_DELETE_WINDOW", on_closing)

def on_keypad_press(entry_widget, key):
    if key == '⌫':
        current_text = entry_widget.get()
        entry_widget.delete(0, tk.END)
        entry_widget.insert(0, current_text[:-1])
    else:
        entry_widget.insert(tk.END, key)

def setup_lock_screen():
    global lock_window, current_qr_code_password, timeout_id # digital_panel_label kaldırıldı

    lock_window = tk.Tk()
    lock_window.title("CBA-Kilit - Akıllı Tahta Kilidi")
    lock_window.attributes('-fullscreen', True)
    lock_window.attributes('-topmost', True)
    lock_window.overrideredirect(True)

    lock_window.protocol("WM_DELETE_WINDOW", on_closing)
    lock_window.config(bg="#2c3e50")

    main_frame = tk.Frame(lock_window, bg="#2c3e50")
    main_frame.pack(fill="both", expand=True)

    canvas = tk.Canvas(main_frame, bg="#2c3e50", highlightthickness=0)
    scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)

    scrollbar.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)

    content_frame = tk.Frame(canvas, bg="#2c3e50")
    canvas_window = canvas.create_window((0, 0), window=content_frame, anchor="nw")

    def on_frame_configure(event):
        canvas.configure(scrollregion=canvas.bbox("all"))
        canvas_width = event.width
        canvas.itemconfig(canvas_window, width=canvas_width)

    content_frame.bind("<Configure>", on_frame_configure)

    # Grid yapılandırması content_frame için
    # Dijital pano satırı kaldırıldı
    content_frame.grid_rowconfigure(0, weight=1) # Başlık
    content_frame.grid_rowconfigure(1, weight=3) # QR Kodu
    content_frame.grid_rowconfigure(2, weight=1) # QR Bilgi Metni
    content_frame.grid_rowconfigure(3, weight=1) # Giriş Alanı
    content_frame.grid_rowconfigure(4, weight=5) # Sanal Klavye
    content_frame.grid_rowconfigure(5, weight=2) # Açma Butonu
    content_frame.grid_columnconfigure(0, weight=1)

    title_label = tk.Label(content_frame, text="CBA-Kilit: Akıllı Tahta Güvenlik Sistemi",
                           font=("Arial", 32, "bold"), fg="white", bg="#2c3e50")
    title_label.grid(row=0, column=0, pady=(40, 10), sticky="n")

    current_qr_code_password = generate_random_qr_password()
    qr_img = generate_qr_code(current_qr_code_password)
    photo = ImageTk.PhotoImage(qr_img)

    qr_label = tk.Label(content_frame, image=photo, bg="#2c3e50")
    qr_label.image = photo
    qr_label.grid(row=1, column=0, pady=10)

    qr_info_label = tk.Label(content_frame, text="Kilidi açmak için QR kodu tarayın veya CBAdmin parolayı girin:",
                             font=("Arial", 16), fg="white", bg="#2c3e50")
    qr_info_label.grid(row=2, column=0, pady=(0, 10))

    password_entry = tk.Entry(content_frame, width=20, font=("Arial", 20), show="*", justify="center", bd=5, relief="ridge")
    password_entry.grid(row=3, column=0, pady=10)
    password_entry.focus_set()

    keypad_frame = tk.Frame(content_frame, bg="#2c3e50")
    keypad_frame.grid(row=4, column=0, pady=10)

    buttons = [
        '1', '2', '3',
        '4', '5', '6',
        '7', '8', '9',
        '', '0', '⌫'
    ]

    row_val = 0
    col_val = 0
    for button_text in buttons:
        if button_text == '':
            col_val += 1
            if col_val > 2:
                col_val = 0
                row_val += 1
            continue

        button = tk.Button(keypad_frame, text=button_text, font=("Arial", 18, "bold"), width=5, height=2,
                           command=lambda bt=button_text: on_keypad_press(password_entry, bt),
                           bg="#34495e", fg="white", relief="raised", bd=3)
        button.grid(row=row_val, column=col_val, padx=5, pady=5)
        col_val += 1
        if col_val > 2:
            col_val = 0
            row_val += 1

    unlock_button = tk.Button(content_frame, text="Kilidi Aç", font=("Arial", 22, "bold"),
                              command=lambda: check_password(password_entry),
                              bg="#27ae60", fg="white", relief="raised", bd=5, width=15)
    unlock_button.grid(row=5, column=0, pady=(10, 40), sticky="s") # Alt boşluğu eski haline getir

    # update_digital_panel() çağrısı kaldırıldı.

    timeout_id = lock_window.after(LOCK_TIMEOUT_SECONDS * 1000, send_to_sleep_or_shutdown)

    lock_window.bind("<Return>", lambda event: check_password(password_entry))
    lock_window.bind("<BackSpace>", lambda event: on_keypad_press(password_entry, '⌫'))
    for i in range(10):
        lock_window.bind(str(i), lambda event, digit=str(i): on_keypad_press(password_entry, digit))

    lock_window.mainloop()

# --- Ana Program Akışı ---
if __name__ == "__main__":
    # Dijital pano dosyası oluşturma kısmı kaldırıldı.

    apply_os_specific_lock()
    disable_system_monitoring()

    setup_lock_screen()
